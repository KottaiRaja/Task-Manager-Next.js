import TaskForm from '@/components/TaskForm'
export default function CreatePage() {
  return <TaskForm />
}
