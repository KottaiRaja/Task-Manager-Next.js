import TaskForm from '@/components/TaskForm'
export default function EditPage() {
  return <TaskForm />
}
