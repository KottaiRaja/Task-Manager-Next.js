import UserForm from '@/components/userForm'
export default function CreatePage() {
  return <UserForm />
}
